from odoo import models, fields,api
from odoo.exceptions import  ValidationError

class PosOrderInherit(models.Model):
    _inherit = 'pos.order'

    customer_name = fields.Char(string="Customer Name")
    mobile_no = fields.Char(string="Mobile Number")
    tin = fields.Char(string="TIN")
    delivery_address = fields.Text(string="Delivery Address")
    is_one_time_persion = fields.Boolean(string='Is One Time Customer', related='partner_id.is_one_time_persion')

    

    

    def _create_invoice(self, move_vals):
        # Call the original method
        invoice = super(PosOrderInherit, self)._create_invoice(move_vals)
        
        # Copy the custom fields to the invoice
        if invoice:
            invoice.write({
                'customer_name': self.customer_name,
                'mobile_no': self.mobile_no,
                'tin': self.tin,
                'delivery_address': self.delivery_address,
                'is_one_time_persion': self.is_one_time_persion,
            })
        return invoice

    
    @api.constrains('partner_id', 'customer_name', 'mobile_no', 'tin', 'delivery_address')
    def _check_one_time_customer_details(self):
        for order in self:
            if order.partner_id.is_one_time_persion:
                if not all([order.customer_name, order.mobile_no, order.tin, order.delivery_address]):
                    raise ValidationError("All customer details are required for one-time customers.")

    
    

    def _order_fields(self, ui_order):
        """To get the value of field in pos session to pos order"""
        res = super()._order_fields(ui_order)
        res['is_one_time_persion'] = ui_order.get('is_one_time_persion')
       
        return res



class ResPartners(models.Model):
    _inherit = 'res.partner'

    is_one_time_persion = fields.Boolean(string='Is One Time Customer')

    @api.model
    def get_pos_visible_fields(self):
        """
        Add `is_one_time_persion` to the list of fields sent to the POS.
        """
        return ['is_one_time_persion']
    
class AccountOrderInherit(models.Model):
    _inherit = 'account.move'

    customer_name = fields.Char(string="Customer Name")
    mobile_no = fields.Char(string="Mobile Number")
    tin = fields.Char(string="TIN")
    delivery_address = fields.Text(string="Delivery Address")
    is_one_time_persion = fields.Boolean(string='Is One Time Customer', related='partner_id.is_one_time_persion')



class PosConfigInherit(models.Model):
    _inherit = 'pos.config'

    @api.model
    def action_open_sale_order_form(self):
        # Open the sale order form view for the related sale order
        return {
            'type': 'ir.actions.act_window',
            'name': 'Sale Order',
            'res_model': 'sale.order',
            'view_mode': 'form',
            'res_id': self.env['sale.order'].search([('pos_order_id', '=', self.id)], limit=1).id,
            'target': 'current',
        }