import { AlertDialog } from "@web/core/confirmation_dialog/confirmation_dialog";
import { _t } from "@web/core/l10n/translation";
import { ControlButtons } from "@point_of_sale/app/screens/product_screen/control_buttons/control_buttons";
import { patch } from "@web/core/utils/patch";
import { TextInputPopup } from "@pos_custom/app/custom_popup/text_input_popup";

patch(ControlButtons.prototype, {
    async onClickPopupSingleField() {
        const collectInputs = async (title) => {
            return new Promise((resolve) => {
                this.dialog.add(TextInputPopup, {
                    title: _t(title),
                    getPayload: async (inputs) => {
                        const { customer_name, mobile_no, tin, delivery_address } = inputs;

                        resolve({ customer_name, mobile_no, tin, delivery_address });
                    },
                });
            });
        };

        // Collect all inputs in one go
        const customer_details = await collectInputs("Enter Customer Details");
        if (!customer_details) return;

        const { customer_name, mobile_no, tin, delivery_address } = customer_details;

        const order = this.pos.get_order();
        const orderLines = order.get_orderlines();

        // Save collected data in the order object
        order.customer_name = customer_name;
        order.mobile_no = mobile_no;
        order.tin = tin || "";
        order.delivery_address = delivery_address || "";

        

        console.log('Customer Details:', {
            customer_name,
            mobile_no,
            tin,
            delivery_address,
        });
    },
});







// patch(ControlButtons.prototype, {
//     async onClickPopupSingleField() {
//         const collectInputs = async (title) => {
//             return new Promise((resolve) => {
//                 this.dialog.add(TextInputPopup, {
//                     title: _t(title),
//                     getPayload: async (inputs) => {
//                         const { customer_name, mobile_no, tin, delivery_address } = inputs;

//                         resolve({ customer_name, mobile_no, tin, delivery_address });
//                     },
//                 });
//             });
//         };

//         // Collect all inputs in one go
//         const customer_details = await collectInputs("Enter Customer Details");
//         if (!customer_details) return;

//         const { customer_name, mobile_no, tin, delivery_address } = customer_details;

//         const order = this.pos.get_order();
//         const orderLines = order.get_orderlines();

//         // Save collected data in the order object
//         order.customer_name = customer_name;
//         order.mobile_no = mobile_no;
//         order.tin = tin || "";
//         order.delivery_address = delivery_address || "";

//         console.log('Customer Details:', {
//             customer_name,
//             mobile_no,
//             tin,
//             delivery_address,
//         });
//     },
// });





