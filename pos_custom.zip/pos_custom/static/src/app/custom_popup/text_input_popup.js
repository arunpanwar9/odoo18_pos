import { Component, onMounted, useRef, useState } from "@odoo/owl";
import { Dialog } from "@web/core/dialog/dialog";

export class TextInputPopup extends Component {
    static template = "pos_custom.TextInputPopup";
    static components = { Dialog };
    static props = {
        title: String,
        buttons: { type: Array, optional: true },
        getPayload: Function,
        close: Function,
    };
    static defaultProps = {
        buttons: [],
    };

    setup() {
        this.state = useState({
            customer_name: "",
            mobile_no: "",
            tin: "",
            delivery_address: "",
        });
        this.inputRefs = {
            customer_name: useRef("customer_name"),
            mobile_no: useRef("mobile_no"),
            tin: useRef("tin"),
            delivery_address: useRef("delivery_address"),
        };

        // Using setTimeout to wait for the rendering cycle to complete
        onMounted(() => {
            setTimeout(() => {
                if (this.inputRefs.customer_name.el) {
                    this.inputRefs.customer_name.el.focus();
                }
            }, 0); // Focus after a single event loop cycle
        });
    }

    confirm() {
        const { customer_name, mobile_no, tin, delivery_address } = this.state;
        const inputs = { customer_name, mobile_no, tin, delivery_address };
        this.props.getPayload(inputs);
        this.props.close();
    }

    close() {
        this.props.close();
    }
}




