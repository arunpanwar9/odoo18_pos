from odoo import http
from odoo.http import request

class PosCustomController(http.Controller):
    @http.route('/pos/check_one_time_customer', type='json', auth='user', csrf=False, methods=["POST"])
    def validate_one_time_customer(self, partner_id):
        partner = request.env['res.partner'].sudo().browse(partner_id)
        if not partner.exists():
            return {"success": False, "message": "Partner not found."}
        
        if partner.is_one_time_persion:
            return {
                "success": True,
                "message": "This is a One-Time Customer, form can be filled.",
            }
        else:
            return {"success": False, "message": "This customer is not eligible to fill out the form."}